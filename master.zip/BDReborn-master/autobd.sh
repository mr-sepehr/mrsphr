#!/bin/bash
COUNTER=1
while(true) do
./beyond.sh
let COUNTER=COUNTER+1 
done
