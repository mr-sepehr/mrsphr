# [BDReborn V6 (Final Version)](https://telegram.me/BDReborn)

**An advanced and powerful administration bot based on NEW TG-CLI


* * *

## Commands

| Use help |
|:--------|:------------|
| [#!/]help | just send help in your group and get the commands |

**You can use "#", "!", or "/" to begin all commands

* * *

# Installation

**If use BDHelper put your helper bot Username Without @ in bot.lua, line 22

```sh
# Let's install the bot.
cd $HOME
git clone https://github.com/BeyondTeam/BDReborn.git
cd BDReborn
chmod +x beyond.sh
./beyond.sh install
./beyond.sh 
# Enter a phone number & confirmation code.

# For Auto Launch:
cd BDReborn
chmod 777 autobd.sh
screen ./autobd.sh
```
### One command
To install everything in one command, use:
```sh
cd $HOME && git clone https://github.com/BeyondTeam/BDReborn.git && cd BDReborn && chmod +x beyond.sh && ./beyond.sh install && ./beyond.sh

OR

cd $HOME && git clone https://github.com/BeyondTeam/BDReborn.git && cd BDReborn && chmod +x beyond.sh && ./beyond.sh install && chmod 777 autobd.sh && screen ./autobd.sh
```

* * *

# Support and Development

More information [Beyond Global Chat](https://telegram.me/joinchat/AAAAAEIDQ8HTjezV4syUSA)

# Special thanks to
[@MrHalix](https://github.com/MrHalix)

[@Vysheng](https://github.com/vysheng)

* * *

# Developers!

[SoLiD](https://github.com/solid021) ([Telegram](https://telegram.me/SoLiD))

[To0fan](https://github.com/To0fan) ([Telegram](https://telegram.me/ToOfan))

[MAKAN](https://github.com/makanj) ([Telegram](https://telegram.me/MAKAN))


### Our Telegram channel:

[@BeyondTeam](https://telegram.me/BeyondTeam)

### Our Web Site:

[Beyond Development Forum](https://Beyond-Dev.iR)
